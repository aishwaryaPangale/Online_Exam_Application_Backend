package com.example.demo.Model;



import java.sql.Date;

import lombok.Data;

@Data
public class Register {
	private String name;
    private String email;
    private String contact;
    private String address;
    private String course;
    private Date birthdate;
    private String gender;
    private String username;
    private String password;
    


}