package com.example.demo.Services;

import com.example.demo.Model.Users;
import com.example.demo.Repository.UsersRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class UserService {

    @Autowired
    private UsersRepo userRepo;
    public boolean updatePassword(String email, String newPassword) {
        Optional<Users> optionalUser = userRepo.findByEmail(email);
        if (optionalUser.isPresent()) {
            Users user = optionalUser.get();
            user.setPassword(newPassword); // In real apps, hash this
            userRepo.save(user);
            return true;
        }
        return false;
    }

    public Optional<Users> getUserByEmail(String email) {
        return userRepo.findByEmail(email);
    }
}
