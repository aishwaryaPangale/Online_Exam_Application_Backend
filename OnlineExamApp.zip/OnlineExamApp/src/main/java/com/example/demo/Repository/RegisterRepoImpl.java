package com.example.demo.Repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.demo.Model.Register;

@Repository
public class RegisterRepoImpl {
	    @Autowired
	    private JdbcTemplate jdbcTemplate;

//	    public boolean existsByEmail(String email) {
//	        String sql = "SELECT COUNT(*) FROM Students WHERE email = ?";
//	        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, email);
//	        return count != null && count > 0;
//	    }

	    public void save(Register user) {
	    	String sql = "INSERT INTO Students (name, email, contact, address, course, birthdate, gender, username, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
	    	jdbcTemplate.update(sql, user.getName(), user.getEmail(), user.getContact(), user.getAddress(),
	    			user.getCourse(), user.getBirthdate(), user.getGender(), user.getUsername(), user.getPassword());

	    }

		public boolean emailExists(String email) {
			 String sql = "SELECT COUNT(*) FROM Students WHERE email = ?";
		        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, email);
		        return count != null && count > 0;
		}

		
}
