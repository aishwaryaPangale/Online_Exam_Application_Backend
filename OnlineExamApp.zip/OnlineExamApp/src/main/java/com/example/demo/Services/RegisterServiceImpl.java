package com.example.demo.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Model.Register;
import com.example.demo.Repository.RegisterRepoImpl;


@Service
public class RegisterServiceImpl{

	@Autowired
	private RegisterRepoImpl regRepo;

    public String register(Register user) {
        if (regRepo.emailExists(user.getEmail())) {
            return "Email already exists";
        }
        regRepo.save(user);
        return "Success";
    }


	
}
