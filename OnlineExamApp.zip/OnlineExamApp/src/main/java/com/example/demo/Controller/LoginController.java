package com.example.demo.Controller;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.Login;
import com.example.demo.Model.Otp;
import com.example.demo.Repository.LoginRepository;
import com.example.demo.Repository.OtpRepository;
import com.example.demo.Services.OtpService;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin("http://localhost:5173") // adjust port if needed
public class LoginController {

	 @Autowired
	    private LoginRepository loginRepo;
	    @Autowired
	    private OtpRepository otpRepository;
	    @Autowired
	    private OtpService otpService;
	    
	    @PostMapping("/send-otp")
	    public ResponseEntity<?> sendOtp(@RequestBody Map<String, String> body) {
	        String email = body.get("email");

	        Optional<Login> user = loginRepo.findByEmail(email);
	        if (user.isEmpty()) {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("message", "❌ Email not registered!"));
	        }

	        String otp = otpService.generateOtp(email);
	        // Normally you send via email here
	        System.out.println("OTP for " + email + " is: " + otp);

	        return ResponseEntity.ok(Map.of("message", "✅ OTP sent to your email!"));
	    }

	    @PostMapping("/verify-otp")
	    public ResponseEntity<?> verifyOtpAndLogin(@RequestBody Map<String, String> body) {
	        String email = body.get("email");
	        String username = body.get("username");
	        String password = body.get("password");
	        String otp = body.get("otp");

	        if (!otpService.validateOtp(email, otp)) {
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("message", "❌ Invalid OTP!"));
	        }

	        Optional<Login> userOpt = loginRepo.findByEmailAndUsernameAndPassword(email, username, password);
	        if (userOpt.isEmpty()) {
	            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("message", "❌ Incorrect login credentials!"));
	        }

	        return ResponseEntity.ok(Map.of("message", "✅ Login successful!"));
	    }


}