package com.example.demo.Model;

import jakarta.persistence.*;

@Entity
@Table(name = "login")
public class Login {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String email;
    private String username;
    private String password;
    
    
    @Column(nullable = false, columnDefinition = "BOOLEAN DEFAULT FALSE") // Ensure default value
    private boolean isVerified = false; 

    public Login() {
    	
    }
    public Login(String email,String username, String password) {
        this.email = email;
        this.username=username;
        this.password = password;
        this.isVerified = false; // Explicitly set default value
    }

	public void setVerified(boolean isVerified) {
		 this.isVerified = isVerified;
		
	}
}



