package com.example.demo.Controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Model.Register;
import com.example.demo.Repository.RegisterRepoImpl;
import com.example.demo.Services.RegisterServiceImpl;


@RestController
//@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:5173")
public class RegisterController {
	@Autowired
	private RegisterServiceImpl regService;
	
	 @Autowired
	    private RegisterRepoImpl registerRepository;
	 @PostMapping("/api/register")
	 public ResponseEntity<String> register(@RequestBody Register register) {
	     String result = regService.register(register);

	     if ("Email already exists".equals(result)) {
	         return ResponseEntity.ok("Email already exists"); // <-- 200 instead of 400
	     }
	     return ResponseEntity.ok("Success");
	 }


}
